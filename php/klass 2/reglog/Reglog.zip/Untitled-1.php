<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registracja</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-color: rgba(194, 193, 191, 1);
            font-family:Arial, Helvetica, sans-serif;
        }
        #rer {
            color: rgba(59, 17, 138, 0.57);
        }
    </style>
</head>

<body>

    <form action="" method="POST">
        <h1>Registracja</h1>
        <label for="user">User</label><br>
        <input type="text" name="user" required><br>
        <label for="password">Password</label><br>
        <input type="password" name="password" required><br>
        <label for="password2">Confirm Password</label><br>
        <input type="password2" name="password2" required><br>
        <button type="submit">Submit</button>
    </form><!--nfsffm-->



    <button><a href="http://localhost/Untitled-2.php">Login</a></button>
   <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $name = $_POST["user"];
        $password = $_POST["password"];
        $password2 = $_POST["password2"];

        if ($password == $password2) {
            echo "<p id='rer'>Hasła identyczne<p>";
            file_put_contents("plik.txt", $name . ",". $password);
       
        } else {
            echo "Hasła są różne<br>";
        }

        echo "Witaj, $name";

       

    }
    ?>

</body>

</html>