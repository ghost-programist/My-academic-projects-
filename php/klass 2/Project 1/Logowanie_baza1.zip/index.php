<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie do systemu</title>

</head>
<body>
    <div class="container">
        <header><h1>Zapis do listy newsów</h1></header>
        <main>
            <article>
                <form action="zapisz.php" method="post">
                    <label>Podaj adres email: <input type="email" name="email" 
                    <?= isset($_SESSION['given_email'])? 'value="'>$_SESSION['given_email'].'"':''?>></label>
                    <input type="submit" value="OK">

                    <?php 
                        if(isset($_SESSION['given_email']))
                        {
                            echo '<p> Proszę podać poprawny adres e-mail</p>';
                            unset($_SESSION['given_email']);
                        }
                    ?>
                </form>
            </article>
        </main>
    </div>
</body>
</html>