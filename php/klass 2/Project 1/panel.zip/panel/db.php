<?php
$conn = mysqli_connect("localhost", "root", "", "panel_admin");

if (!$conn) {
    die("Błąd połączenia z bazą");
}
?>