<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            
            background-color: rgba(194, 193, 191, 1);
            font-family: Arial, Helvetica, sans-serif;
        }

        #rer {
            color: rgba(59, 17, 138, 0.57);
        }
        input:focus {
            border: none;
            outline: none;
            border-radius: 4px;
            border:3px ridge blue;
            background: rgba(207, 226, 207, 1);
        }
        input:valid {
            background: rgba(81, 223, 81, 0.62);
        }
        input:invalid {
            background: rgba(230, 44, 44, 0.62);
        }
        button {
            margin-top: 10px;
        }
    </style>
</head>

<body>

    <form action="" method="POST">
        <h1>Login</h1>
        <label for="user">User</label><br>
        <input type="text" name="user" required><br>
        <label for="password">Password</label><br>
        <input type="password" name="password" required><br>

        <button type="submit">Zaloguj sie</button>

    </form><!--nfsffm-->
   
<?php
   if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $f = fopen("plik.txt", "r");
    $name1 = $_POST["user"];
    $password1 = $_POST["password"];
    $dane = fgets($f);
    $tab = explode(",", $dane);
    echo $dane;
  
    if ($name1 == $tab[0]) {
        echo "<br>napisano prowidlowe imie<br>";
    }
    else {
        echo "<br>napisano nie prowidlowe imie<br>";
    }

    if ($password1 == $tab[1]) {
        echo "napisan prowidlowy pasword<br>";
    }
    else {
        echo "napisan nie prowidlowy pasword<br>";
    }
 }
    ?>