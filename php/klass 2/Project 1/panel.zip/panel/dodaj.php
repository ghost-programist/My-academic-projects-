<?php
session_start();
include("db.php");

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nazwa = $_POST["nazwa"];
    $cena = $_POST["cena"];

    $sql = "INSERT INTO produkty (nazwa, cena) VALUES ('$nazwa', '$cena')";
    mysqli_query($conn, $sql);

    echo "Produkt dodany<br>";
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>

<h2>Dodaj produkt</h2>

<form method="POST">
    Nazwa: <input type="text" name="nazwa"><br>
    Cena: <input type="number" step="0.01" name="cena"><br>
    <button type="submit">Dodaj</button>
</form>

<a href="panel.php">Powrót</a>

</body>
</html>