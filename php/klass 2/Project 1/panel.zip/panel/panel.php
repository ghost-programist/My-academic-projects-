<?php
session_start();
include("db.php");

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

$result = mysqli_query($conn, "SELECT * FROM produkty");
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>

<h2>Panel administratora</h2>

<a href="dodaj.php">Dodaj produkt</a> |
<a href="logout.php">Wyloguj</a>

<table border="1">
<tr>
    <th>ID</th>
    <th>Nazwa</th>
    <th>Cena</th>
    <th>Usuń</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td><?php echo $row["id"]; ?></td>
    <td><?php echo $row["nazwa"]; ?></td>
    <td><?php echo $row["cena"]; ?></td>
    <td><a href="usun.php?id=<?php echo $row["id"]; ?>">Usuń</a></td>
</tr>
<?php } ?>

</table>

</body>
</html>