package dane;

public class Osoba {

    String nazwa;      
    int waga;          
    double wzrost;     
    int wiek;          
    boolean płeć;      

    public Osoba() {
        this.nazwa = "Jan Nowak";
        this.wiek = 40;
        this.wzrost = 1.77;
        this.waga = 83;
        this.płeć = true; 
    }

    
    public Osoba(String nazwa, int waga, double wzrost, int wiek, boolean płeć) {
        if (nazwa == null || nazwa.isEmpty()) {
            throw new IllegalArgumentException("Nazwa nie może być pusta!");
        }
        if (waga <= 20 || waga >= 200) {
            throw new IllegalArgumentException("Waga spoza zakresu (20-200)!");
        }
        if (wzrost <= 1 || wzrost >= 2.5) {
            throw new IllegalArgumentException("Wzrost spoza zakresu (1-2.5)!");
        }
        if (wiek <= 15 || wiek >= 75) {
            throw new IllegalArgumentException("Wiek spoza zakresu (15-75)!");
        }

        this.nazwa = nazwa;
        this.waga = waga;
        this.wzrost = wzrost;
        this.wiek = wiek;
        this.płeć = płeć;
    }

   
    public double obliczBMI() {
        return waga / (wzrost * wzrost);
    }

  
    public double obliczBMIRozszerzone() {
        int p = płeć ? 2 : 3; 
        return waga / (wzrost * wzrost) - wiek / 10.0 + p;
    }

    @Override
    public String toString() {
        return "Osoba: " + nazwa +
                ", waga=" + waga +
                ", wzrost=" + wzrost +
                ", wiek=" + wiek +
                ", płeć=" + (płeć ? "mężczyzna" : "kobieta");
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Osoba)) return false;
        Osoba o = (Osoba) obj;
        return this.nazwa.equals(o.nazwa);
    }
}
