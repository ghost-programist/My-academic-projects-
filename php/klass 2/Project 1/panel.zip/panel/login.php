<?php
session_start();
include("db.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = $_POST["login"];
    $haslo = $_POST["haslo"];

    $sql = "SELECT * FROM uzytkownicy WHERE login='$login' AND haslo='$haslo'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $_SESSION["user"] = $login;
        header("Location: panel.php");
        exit();
    } else {
        $error = "Błędny login lub hasło";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>

<h2>Logowanie</h2>

<form method="POST">
    Login: <input type="text" name="login"><br>
    Hasło: <input type="password" name="haslo"><br>
    <button type="submit">Zaloguj</button>
</form>

<p style="color:red;"><?php echo $error; ?></p>

</body>
</html>