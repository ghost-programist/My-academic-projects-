<?php
session_start();
include("db.php");

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

$id = $_GET["id"];

mysqli_query($conn, "DELETE FROM produkty WHERE id=$id");

header("Location: panel.php");
exit();
?>