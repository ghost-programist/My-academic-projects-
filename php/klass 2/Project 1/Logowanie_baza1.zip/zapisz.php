<?php
session_start();

if (isset($_POST['email']))
{
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);

    if (empty($email))
    {
        $_SESSION['given_email'] = $_POST['email'];
        header('Location: index.php');
    }
    else
    {
        require_once 'baza.php';
        $query = $db->prepare('INSERT INTO users VALUES (NULL, :email)');
        $query->bindValue(':email', $email, PDO::PARAM_STR);
        $query->execute();
    }
}
else
{
    header('Location: index.php');
    exit;
}


?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zapis na wysyłkę newsów odnośnie świata PHP</title>
</head>
<body>
    <div class="container">
        <header>
            <h1>Najświeższe informacje ze świata PHP będą na twoim mailu</h1>
        </header>
        <main>
            <article>
                <p> Dziekujemy za zapisanie się na blabla bla</p>
            </article>
        </main>
    </div>
    
</body>
</html>